#pragma once

// include guards for doubly-declared functions
#ifndef USER_HEADER
#define USER_HEADER

void free_args();
int get_input(char* user_input);
void dolla_dolla();

#endif