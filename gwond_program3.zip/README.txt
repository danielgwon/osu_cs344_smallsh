CS344 - Operating Systems
Portfolio Project
Daniel Gwon

To compile:
gcc --std=gnu99 -o smallsh main.c built-in.c signals.c processes.c user.c

To run:
./smallsh