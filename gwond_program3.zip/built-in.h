#pragma once

// include guards for doubly-declared functions
#ifndef BUILTIN_HEADER
#define BUILTIN_HEADER

void change_dir();
void processes_clean_up();
void get_status();

#endif